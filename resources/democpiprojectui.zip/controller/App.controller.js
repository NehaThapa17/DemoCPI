sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("demo.cpi.projectui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map